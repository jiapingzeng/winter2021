NAME: Jiaping Zeng
EMAIL: jiapingzeng@ucla.edu
ID: 905363270

Included files:
- create.sql: creates 8 tables as specified
- load.sql: loads supplied data into the created tables
- q1.sql: selects dob of the actor with id 65793
- q2.sql: selects first and last names of all the actors in the movie ‘Die Another Day’